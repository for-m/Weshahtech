ضع aria2c.exe هنا (يُجلب تلقائياً بـ npm run engine أو عبر GitHub Actions)
