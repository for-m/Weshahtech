// إضافة وشاح: تلتقط التحميلات وترسلها إلى التطبيق
const BRIDGE = 'http://127.0.0.1:16801';
const passThrough = new Set();

async function appAlive() {
  try {
    const r = await fetch(`${BRIDGE}/ping`, { signal: AbortSignal.timeout(700) });
    return r.ok;
  } catch {
    return false;
  }
}

async function cookiesFor(url) {
  try {
    const list = await chrome.cookies.getAll({ url });
    return list.map((c) => `${c.name}=${c.value}`).join('; ');
  } catch {
    return '';
  }
}

async function sendToWishah(url, extra = {}) {
  const cookie = /^https?:/i.test(url) ? await cookiesFor(url) : '';
  const r = await fetch(`${BRIDGE}/add`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url, cookie, userAgent: navigator.userAgent, ...extra }),
  });
  return r.ok;
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: 'wishah', title: 'تحميل بواسطة وشاح', contexts: ['link', 'video', 'audio', 'image'] });
  chrome.storage.local.get(['enabled', 'minSizeMB'], (v) => {
    chrome.storage.local.set({ enabled: v.enabled ?? true, minSizeMB: v.minSizeMB ?? 1 });
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const url = info.linkUrl || info.srcUrl;
  if (!url) return;
  if (!(await appAlive())) return;
  sendToWishah(url, { referer: tab && tab.url });
});

chrome.downloads.onCreated.addListener(async (item) => {
  const { enabled = true, minSizeMB = 1 } = await chrome.storage.local.get(['enabled', 'minSizeMB']);
  const url = item.finalUrl || item.url;
  if (!enabled || passThrough.has(url)) { passThrough.delete(url); return; }
  if (!/^(https?|ftp):/i.test(url)) return; // blob: و data: تبقى في المتصفح
  if (item.fileSize > 0 && item.fileSize < minSizeMB * 1048576) return;
  if (!(await appAlive())) return;

  try {
    await chrome.downloads.cancel(item.id);
    await chrome.downloads.erase({ id: item.id });
  } catch {}

  const filename = (item.filename || '').split(/[\\/]/).pop();
  let ok = false;
  try { ok = await sendToWishah(url, { referer: item.referrer, filename }); } catch {}
  if (!ok) {
    passThrough.add(url);
    chrome.downloads.download({ url });
  }
});
