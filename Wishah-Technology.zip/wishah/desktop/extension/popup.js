const $ = (s) => document.querySelector(s);
chrome.storage.local.get(['enabled', 'minSizeMB'], (v) => {
  $('#enabled').checked = v.enabled ?? true;
  $('#minSize').value = v.minSizeMB ?? 1;
});
$('#enabled').addEventListener('change', (e) => chrome.storage.local.set({ enabled: e.target.checked }));
$('#minSize').addEventListener('change', (e) => chrome.storage.local.set({ minSizeMB: Number(e.target.value) || 0 }));
fetch('http://127.0.0.1:16801/ping', { signal: AbortSignal.timeout(800) })
  .then((r) => { if (!r.ok) throw 0; $('#status').textContent = 'متصل'; })
  .catch(() => { $('#status').textContent = 'غير مشغّل'; $('#status').className = 'off'; });
