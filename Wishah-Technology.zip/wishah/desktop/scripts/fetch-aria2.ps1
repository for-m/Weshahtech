# Fetch the official aria2 engine into ./engine
$ErrorActionPreference = "Stop"
$ver = "1.37.0"
$url = "https://github.com/aria2/aria2/releases/download/release-$ver/aria2-$ver-win-64bit-build1.zip"
$root = Split-Path -Parent $PSScriptRoot
$tmp = Join-Path $env:TEMP "aria2.zip"
Invoke-WebRequest -Uri $url -OutFile $tmp
$dst = Join-Path $env:TEMP "aria2x"
if (Test-Path $dst) { Remove-Item $dst -Recurse -Force }
Expand-Archive $tmp -DestinationPath $dst
New-Item -ItemType Directory -Force -Path (Join-Path $root "engine") | Out-Null
Get-ChildItem $dst -Recurse -Filter aria2c.exe | Select-Object -First 1 | Copy-Item -Destination (Join-Path $root "engine\aria2c.exe") -Force
Write-Host "engine/aria2c.exe ready"
