const fs = require('fs');
const path = require('path');

class Store {
  constructor(dir, defaults) {
    this.file = path.join(dir, 'settings.json');
    this.data = { ...defaults };
    try {
      Object.assign(this.data, JSON.parse(fs.readFileSync(this.file, 'utf8')));
    } catch {}
    this.save();
  }
  get(key) {
    return this.data[key];
  }
  all() {
    return JSON.parse(JSON.stringify(this.data));
  }
  set(patch) {
    Object.assign(this.data, patch);
    this.save();
  }
  save() {
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    const tmp = `${this.file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(this.data, null, 2));
    fs.renameSync(tmp, this.file);
  }
}

module.exports = Store;
