const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('wishah', {
  rpc: (method, params) => ipcRenderer.invoke('rpc', method, params),
  multicall: (calls) => ipcRenderer.invoke('multicall', calls),
  getSettings: () => ipcRenderer.invoke('settings:get'),
  setSettings: (patch) => ipcRenderer.invoke('settings:set', patch),
  pickDir: () => ipcRenderer.invoke('dialog:dir'),
  pickTorrent: () => ipcRenderer.invoke('dialog:torrent'),
  showItem: (p) => ipcRenderer.invoke('shell:showItem', p),
  openPath: (p) => ipcRenderer.invoke('shell:openPath', p),
  openExtensionFolder: () => ipcRenderer.invoke('shell:openExtension'),
  deleteFiles: (paths) => ipcRenderer.invoke('file:delete', paths),
  fetchTrackers: () => ipcRenderer.invoke('trackers:fetch'),
  shutdown: () => ipcRenderer.invoke('power:shutdown'),
  abortShutdown: () => ipcRenderer.invoke('power:abort'),
  copy: (text) => ipcRenderer.send('clipboard:write', text),
  notify: (title, body) => ipcRenderer.send('notify', title, body),
  setTray: (text) => ipcRenderer.send('tray', text),
  win: (action) => ipcRenderer.send('win', action),
  onExternal: (cb) => ipcRenderer.on('external-add', (_e, d) => cb(d)),
  onWinState: (cb) => ipcRenderer.on('win-state', (_e, s) => cb(s)),
  ready: () => ipcRenderer.send('renderer-ready'),
});
