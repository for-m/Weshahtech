// محرك وشاح: يشغّل aria2c ويتخاطب معه عبر JSON-RPC
const { spawn } = require('child_process');
const fs = require('fs');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

class Aria2 {
  constructor({ bin, port, secret, sessionFile, options }) {
    this.bin = bin;
    this.port = port;
    this.secret = secret;
    this.sessionFile = sessionFile;
    this.options = options || {};
    this.proc = null;
    this.stopping = false;
    this.restarts = 0;
  }

  get url() {
    return `http://127.0.0.1:${this.port}/jsonrpc`;
  }

  start() {
    if (!fs.existsSync(this.bin)) throw new Error(`محرك التحميل غير موجود: ${this.bin}`);
    if (!fs.existsSync(this.sessionFile)) fs.writeFileSync(this.sessionFile, '');
    const base = [
      '--enable-rpc=true',
      `--rpc-listen-port=${this.port}`,
      `--rpc-secret=${this.secret}`,
      '--rpc-listen-all=false',
      '--rpc-max-request-size=64M',
      `--input-file=${this.sessionFile}`,
      `--save-session=${this.sessionFile}`,
      '--save-session-interval=15',
      '--auto-save-interval=15',
      '--continue=true',
      '--file-allocation=none',
      '--disk-cache=64M',
      '--max-tries=10',
      '--retry-wait=3',
      '--connect-timeout=20',
      '--timeout=60',
      '--lowest-speed-limit=0',
      '--auto-file-renaming=true',
      '--allow-overwrite=false',
      '--content-disposition-default-utf8=true',
      '--http-accept-gzip=true',
      '--enable-dht=true',
      '--enable-dht6=true',
      '--enable-peer-exchange=true',
      '--bt-enable-lpd=true',
      '--bt-max-peers=128',
      '--bt-request-peer-speed-limit=10M',
      '--follow-torrent=true',
      '--follow-metalink=true',
      '--bt-save-metadata=true',
      '--bt-load-saved-metadata=true',
      '--seed-ratio=1.0',
      '--summary-interval=0',
      '--console-log-level=warn',
    ];
    const extra = Object.entries(this.options)
      .filter(([, v]) => v !== '' && v !== null && v !== undefined)
      .map(([k, v]) => `--${k}=${v}`);

    this.proc = spawn(this.bin, [...base, ...extra], { windowsHide: true, stdio: 'ignore' });
    this.proc.on('exit', () => {
      this.proc = null;
      if (!this.stopping && this.restarts < 5) {
        this.restarts += 1;
        setTimeout(() => this.start(), 1500);
      }
    });
  }

  async raw(method, params) {
    const body = JSON.stringify({ jsonrpc: '2.0', id: `${Date.now()}${Math.random()}`, method, params });
    const res = await fetch(this.url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body });
    const json = await res.json();
    if (json.error) throw new Error(json.error.message);
    return json.result;
  }

  call(method, params = []) {
    return this.raw(method, [`token:${this.secret}`, ...params]);
  }

  multicall(calls) {
    const list = calls.map(([methodName, ...p]) => ({ methodName, params: [`token:${this.secret}`, ...p] }));
    return this.raw('system.multicall', [list]);
  }

  async waitReady() {
    for (let i = 0; i < 60; i++) {
      try {
        await this.call('aria2.getVersion');
        return true;
      } catch {
        await sleep(250);
      }
    }
    return false;
  }

  async stop() {
    this.stopping = true;
    try {
      await this.call('aria2.saveSession');
      await this.call('aria2.shutdown');
    } catch {}
    await sleep(600);
    if (this.proc) this.proc.kill();
  }
}

module.exports = Aria2;
