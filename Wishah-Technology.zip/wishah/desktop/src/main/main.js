// وشاح للتكنولوجيا — العملية الرئيسية
const {
  app, BrowserWindow, ipcMain, Tray, Menu, nativeImage, clipboard,
  shell, dialog, Notification,
} = require('electron');
const path = require('path');
const fs = require('fs');
const http = require('http');
const crypto = require('crypto');
const { exec } = require('child_process');
const Store = require('./store');
const Aria2 = require('./aria2');

const RPC_PORT = 16800;
const BRIDGE_PORT = 16801;
const UA_PRESETS = {
  chrome: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
  firefox: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:130.0) Gecko/20100101 Firefox/130.0',
  aria2: 'aria2/1.37.0',
};
const FILE_RX = /^(https?|ftp|sftp):\/\/\S+\.(zip|rar|7z|tar|gz|bz2|xz|iso|img|exe|msi|apk|xapk|dmg|deb|rpm|appimage|mp4|mkv|avi|mov|webm|m4v|flv|wmv|ts|mp3|flac|wav|m4a|aac|ogg|opus|pdf|epub|docx?|xlsx?|pptx?|torrent|metalink|bin|cab|jar)(\?\S*)?$/i;

app.setAppUserModelId('com.wishah.downloader');

let win = null;
let tray = null;
let aria2 = null;
let store = null;
let quitting = false;
let rendererReady = false;
const pending = [];

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', (_e, argv) => {
    showWindow();
    handleArgs(argv);
  });
  app.whenReady().then(boot);
}

function defaults() {
  return {
    dir: app.getPath('downloads'),
    maxConcurrent: 5,
    split: 32,
    maxConnPerServer: 16,
    minSplitSize: '1M',
    downLimit: 0,
    upLimit: 0,
    uaPreset: 'chrome',
    userAgent: UA_PRESETS.chrome,
    proxy: '',
    trackers: '',
    seedRatio: 1.0,
    theme: 'dark',
    clipboardMonitor: true,
    notifications: true,
    minimizeToTray: true,
    openAtLogin: false,
    browserAutoStart: false,
    shutdownWhenDone: false,
    schedule: { enabled: false, start: '02:00', stop: '07:00' },
    secret: crypto.randomBytes(16).toString('hex'),
  };
}

function engineOptions(s) {
  return {
    dir: s.dir,
    'max-concurrent-downloads': s.maxConcurrent,
    split: s.split,
    'max-connection-per-server': Math.min(16, s.maxConnPerServer),
    'min-split-size': s.minSplitSize,
    'max-overall-download-limit': s.downLimit ? `${s.downLimit}K` : 0,
    'max-overall-upload-limit': s.upLimit ? `${s.upLimit}K` : 0,
    'user-agent': s.userAgent,
    'all-proxy': s.proxy || '',
    'bt-tracker': (s.trackers || '').split(/[\s,]+/).filter(Boolean).join(','),
    'seed-ratio': s.seedRatio,
  };
}

function enginePath() {
  return app.isPackaged
    ? path.join(process.resourcesPath, 'engine', 'aria2c.exe')
    : path.join(__dirname, '..', '..', 'engine', process.platform === 'win32' ? 'aria2c.exe' : 'aria2c');
}

function iconPath(name) {
  return path.join(__dirname, '..', '..', 'build', name);
}

async function boot() {
  store = new Store(app.getPath('userData'), defaults());
  createWindow();
  createTray();

  aria2 = new Aria2({
    bin: enginePath(),
    port: RPC_PORT,
    secret: store.get('secret'),
    sessionFile: path.join(app.getPath('userData'), 'wishah.session'),
    options: engineOptions(store.all()),
  });
  try {
    aria2.start();
    const ok = await aria2.waitReady();
    if (!ok) throw new Error('تعذر تشغيل محرك التحميل. تأكد أن المنفذ 16800 غير مستخدم.');
  } catch (err) {
    dialog.showErrorBox('وشاح', err.message);
  }

  startBridge();
  startClipboardWatch();
  startScheduler();
  handleArgs(process.argv);
}

function createWindow() {
  win = new BrowserWindow({
    width: 1220,
    height: 780,
    minWidth: 940,
    minHeight: 600,
    frame: false,
    show: false,
    backgroundColor: '#0E1020',
    icon: iconPath('icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
  win.once('ready-to-show', () => {
    if (!process.argv.includes('--hidden')) win.show();
  });
  win.on('close', (e) => {
    if (!quitting && store.get('minimizeToTray')) {
      e.preventDefault();
      win.hide();
    }
  });
  win.on('maximize', () => send('win-state', 'max'));
  win.on('unmaximize', () => send('win-state', 'normal'));
  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

function createTray() {
  const img = nativeImage.createFromPath(iconPath('tray.png'));
  tray = new Tray(img.isEmpty() ? nativeImage.createEmpty() : img);
  tray.setToolTip('وشاح');
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'فتح وشاح', click: showWindow },
    { type: 'separator' },
    { label: 'استئناف الكل', click: () => aria2.call('aria2.unpauseAll').catch(() => {}) },
    { label: 'إيقاف الكل مؤقتاً', click: () => aria2.call('aria2.pauseAll').catch(() => {}) },
    { type: 'separator' },
    { label: 'خروج', click: () => { quitting = true; app.quit(); } },
  ]));
  tray.on('click', showWindow);
}

function showWindow() {
  if (!win) return;
  if (win.isMinimized()) win.restore();
  win.show();
  win.focus();
}

function send(channel, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, payload);
}

function sendExternal(payload) {
  if (rendererReady) send('external-add', payload);
  else pending.push(payload);
}

function handleArgs(argv) {
  for (const arg of argv.slice(1)) {
    if (/^magnet:\?/i.test(arg)) {
      sendExternal({ urls: [arg], source: 'system' });
      showWindow();
    } else if (arg.toLowerCase().endsWith('.torrent') && fs.existsSync(arg)) {
      const base64 = fs.readFileSync(arg).toString('base64');
      sendExternal({ torrent: { name: path.basename(arg), base64 }, source: 'system' });
      showWindow();
    }
  }
}

// جسر إضافة المتصفح: يستقبل الروابط من إضافة كروم/إيدج فقط
function startBridge() {
  const server = http.createServer((req, res) => {
    const origin = req.headers.origin || '';
    const allowed = !origin || origin.startsWith('chrome-extension://') || origin.startsWith('extension://');
    if (!allowed) { res.statusCode = 403; return res.end(); }
    res.setHeader('Access-Control-Allow-Origin', origin || '*');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Content-Type', 'application/json');
    if (req.method === 'OPTIONS') return res.end();
    if (req.url === '/ping') return res.end(JSON.stringify({ app: 'wishah', version: app.getVersion() }));
    if (req.url === '/add' && req.method === 'POST') {
      let body = '';
      req.on('data', (c) => { body += c; if (body.length > 2e6) req.destroy(); });
      req.on('end', () => {
        try {
          const d = JSON.parse(body);
          if (!d.url || !/^(https?|ftp|magnet):/i.test(d.url)) throw new Error('bad url');
          sendExternal({
            urls: [d.url], filename: d.filename, referer: d.referer,
            cookie: d.cookie, userAgent: d.userAgent, source: 'browser',
            autoStart: !!store.get('browserAutoStart'),
          });
          if (!store.get('browserAutoStart')) showWindow();
          res.end('{"ok":true}');
        } catch {
          res.statusCode = 400;
          res.end('{"ok":false}');
        }
      });
      return;
    }
    res.statusCode = 404;
    res.end();
  });
  server.on('error', () => {});
  server.listen(BRIDGE_PORT, '127.0.0.1');
}

function startClipboardWatch() {
  let last = clipboard.readText().trim();
  setInterval(() => {
    if (!store.get('clipboardMonitor')) return;
    const text = clipboard.readText().trim();
    if (!text || text === last || text.length > 4000) return;
    last = text;
    if (/^magnet:\?/i.test(text) || FILE_RX.test(text)) sendExternal({ urls: [text], source: 'clipboard' });
  }, 1200);
}

function startScheduler() {
  let fired = '';
  setInterval(() => {
    const s = store.get('schedule');
    if (!s || !s.enabled || !aria2) return;
    const d = new Date();
    const hm = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
    const key = `${d.toDateString()} ${hm}`;
    if (key === fired) return;
    if (hm === s.start) { fired = key; aria2.call('aria2.unpauseAll').catch(() => {}); notify('وشاح', 'بدأت التحميلات المجدولة'); }
    if (hm === s.stop) { fired = key; aria2.call('aria2.pauseAll').catch(() => {}); notify('وشاح', 'أُوقفت التحميلات حسب الجدول'); }
  }, 15000);
}

function notify(title, body) {
  if (!store.get('notifications') || !Notification.isSupported()) return;
  const n = new Notification({ title, body, icon: iconPath('icon.png'), silent: false });
  n.on('click', showWindow);
  n.show();
}

// ——— IPC ———
ipcMain.handle('rpc', (_e, method, params) => aria2.call(method, params || []));
ipcMain.handle('multicall', (_e, calls) => aria2.multicall(calls));
ipcMain.handle('settings:get', () => ({ ...store.all(), uaPresets: UA_PRESETS, rpcPort: RPC_PORT, bridgePort: BRIDGE_PORT, version: app.getVersion() }));
ipcMain.handle('settings:set', async (_e, patch) => {
  if (patch.uaPreset && patch.uaPreset !== 'custom') patch.userAgent = UA_PRESETS[patch.uaPreset];
  store.set(patch);
  const s = store.all();
  app.setLoginItemSettings({ openAtLogin: !!s.openAtLogin, args: ['--hidden'] });
  const opts = engineOptions(s);
  const runtime = {};
  for (const k of Object.keys(opts)) runtime[k] = String(opts[k]);
  try { await aria2.call('aria2.changeGlobalOption', [runtime]); } catch (err) { return { ok: false, error: err.message }; }
  return { ok: true };
});
ipcMain.handle('dialog:dir', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openDirectory', 'createDirectory'] });
  return r.canceled ? null : r.filePaths[0];
});
ipcMain.handle('dialog:torrent', async () => {
  const r = await dialog.showOpenDialog(win, { filters: [{ name: 'Torrent', extensions: ['torrent'] }], properties: ['openFile'] });
  if (r.canceled) return null;
  const p = r.filePaths[0];
  return { name: path.basename(p), base64: fs.readFileSync(p).toString('base64') };
});
ipcMain.handle('shell:showItem', (_e, p) => { if (fs.existsSync(p)) shell.showItemInFolder(p); else shell.openPath(path.dirname(p)); });
ipcMain.handle('shell:openPath', (_e, p) => shell.openPath(p));
ipcMain.handle('shell:openExtension', () => shell.openPath(app.isPackaged ? path.join(process.resourcesPath, 'extension') : path.join(__dirname, '..', '..', 'extension')));
ipcMain.handle('file:delete', async (_e, paths) => {
  for (const p of paths || []) {
    for (const f of [p, `${p}.aria2`]) {
      try { await fs.promises.rm(f, { recursive: true, force: true }); } catch {}
    }
  }
  return true;
});
ipcMain.handle('trackers:fetch', async () => {
  const res = await fetch('https://cdn.jsdelivr.net/gh/ngosang/trackerslist@master/trackers_best.txt');
  if (!res.ok) throw new Error('تعذر جلب قائمة المتتبعات');
  return (await res.text()).split(/\s+/).filter(Boolean).join('\n');
});
ipcMain.handle('power:shutdown', () => exec('shutdown /s /t 60 /c "وشاح: اكتملت جميع التحميلات"'));
ipcMain.handle('power:abort', () => exec('shutdown /a'));
ipcMain.on('clipboard:write', (_e, t) => clipboard.writeText(String(t)));
ipcMain.on('notify', (_e, title, body) => notify(title, body));
ipcMain.on('tray', (_e, text) => tray && tray.setToolTip(text));
ipcMain.on('win', (_e, action) => {
  if (!win) return;
  if (action === 'min') win.minimize();
  if (action === 'max') (win.isMaximized() ? win.unmaximize() : win.maximize());
  if (action === 'close') win.close();
});
ipcMain.on('renderer-ready', () => {
  rendererReady = true;
  while (pending.length) send('external-add', pending.shift());
});

app.on('before-quit', async (e) => {
  quitting = true;
  if (aria2 && !aria2.stopping) {
    e.preventDefault();
    await aria2.stop();
    app.quit();
  }
});
app.on('window-all-closed', () => {});
