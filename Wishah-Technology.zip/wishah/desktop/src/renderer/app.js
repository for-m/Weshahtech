// وشاح — منطق الواجهة
const api = window.wishah;
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];

const KEYS = ['gid', 'status', 'totalLength', 'completedLength', 'downloadSpeed', 'uploadSpeed',
  'connections', 'numSeeders', 'files', 'bittorrent', 'dir', 'errorMessage', 'infoHash', 'followedBy'];
const CATS = {
  video: ['mp4', 'mkv', 'avi', 'mov', 'webm', 'flv', 'wmv', 'm4v', 'ts', '3gp'],
  audio: ['mp3', 'flac', 'wav', 'aac', 'm4a', 'ogg', 'opus', 'wma'],
  doc: ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'epub', 'csv', 'rtf'],
  archive: ['zip', 'rar', '7z', 'tar', 'gz', 'bz2', 'xz', 'iso', 'img', 'cab'],
  app: ['exe', 'msi', 'apk', 'xapk', 'dmg', 'deb', 'rpm', 'appimage', 'jar'],
  image: ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp', 'heic', 'avif'],
};
const STATUS_AR = { active: 'يُحمَّل', waiting: 'في الانتظار', paused: 'متوقف مؤقتاً', complete: 'مكتمل', error: 'فشل', removed: 'أُزيل' };
const ICONS = {
  pause: '<svg viewBox="0 0 24 24"><path d="M9 5v14M15 5v14"/></svg>',
  play: '<svg viewBox="0 0 24 24"><path d="M8 5l11 7-11 7z"/></svg>',
  retry: '<svg viewBox="0 0 24 24"><path d="M4 12a8 8 0 1 0 2.3-5.6M4 4v5h5"/></svg>',
  folder: '<svg viewBox="0 0 24 24"><path d="M3 7h6l2 2h10v10H3z"/></svg>',
  open: '<svg viewBox="0 0 24 24"><path d="M14 4h6v6M20 4l-9 9M18 14v6H4V6h6"/></svg>',
  link: '<svg viewBox="0 0 24 24"><path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/></svg>',
  trash: '<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/></svg>',
};

const state = {
  tasks: [], filter: 'all', cat: 'all', q: '', settings: {}, rows: new Map(),
  prev: new Map(), spark: new Array(60).fill(0), hadWork: false, torrent: null, busy: false,
};

// ——— أدوات التنسيق ———
function fmtBytes(n) {
  n = Number(n) || 0;
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return `\u2066${n.toFixed(n < 10 && i ? 2 : n < 100 && i ? 1 : 0)} ${u[i]}\u2069`;
}
const fmtSpeed = (n) => `\u2066${fmtBytes(n)}/s\u2069`;
function fmtEta(t) {
  const left = t.totalLength - t.completedLength;
  if (t.status !== 'active' || !t.downloadSpeed || left <= 0) return '—';
  let s = Math.round(left / t.downloadSpeed);
  const h = Math.floor(s / 3600); s -= h * 3600;
  const m = Math.floor(s / 60); s -= m * 60;
  if (h > 99) return 'أكثر من يوم';
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${m}:${String(s).padStart(2, '0')}`;
}
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function taskName(t) {
  if (t.bittorrent && t.bittorrent.info && t.bittorrent.info.name) return t.bittorrent.info.name;
  const f = t.files && t.files[0];
  if (f && f.path) return f.path.split(/[\\/]/).pop();
  const uri = f && f.uris && f.uris[0] && f.uris[0].uri;
  if (uri) {
    if (uri.startsWith('magnet:')) {
      const dn = /[?&]dn=([^&]+)/.exec(uri);
      return dn ? decodeURIComponent(dn[1].replace(/\+/g, ' ')) : 'جلب بيانات المغناطيس…';
    }
    try { return decodeURIComponent(uri.split('?')[0].split('/').pop()) || uri; } catch { return uri; }
  }
  return t.infoHash ? 'جلب بيانات التورنت…' : `مهمة ${t.gid}`;
}
function taskPath(t) {
  if (t.bittorrent && t.bittorrent.info && t.dir) return `${t.dir}\\${t.bittorrent.info.name}`;
  const f = t.files && t.files[0];
  return f && f.path ? f.path : t.dir || '';
}
const ext = (name) => (/\.([a-z0-9]{1,8})$/i.exec(name) || [, ''])[1].toLowerCase();
function catOf(t) {
  if (t.bittorrent || t.infoHash) return 'torrent';
  const e = ext(t.name);
  for (const [k, list] of Object.entries(CATS)) if (list.includes(e)) return k;
  return 'other';
}
function bucket(status) {
  if (status === 'active') return 'active';
  if (status === 'waiting' || status === 'paused') return 'waiting';
  if (status === 'complete') return 'complete';
  return 'error';
}

// ——— التحديث الدوري ———
async function refresh() {
  if (state.busy) return;
  state.busy = true;
  try {
    const r = await api.multicall([
      ['aria2.tellActive', KEYS],
      ['aria2.tellWaiting', 0, 1000, KEYS],
      ['aria2.tellStopped', 0, 1000, KEYS],
      ['aria2.getGlobalStat'],
    ]);
    const [a, w, s, g] = r.map((x) => (Array.isArray(x) ? x[0] : null));
    const list = [...(a || []), ...(w || []), ...(s || [])].map((t) => {
      const o = { ...t };
      ['totalLength', 'completedLength', 'downloadSpeed', 'uploadSpeed', 'connections', 'numSeeders'].forEach((k) => { o[k] = Number(o[k] || 0); });
      o.name = taskName(o);
      o.cat = catOf(o);
      return o;
    });
    detectTransitions(list);
    state.tasks = list;
    if (g) updateGlobal(g);
    render();
  } catch {
    // المحرك يعيد التشغيل — نحاول لاحقاً
  } finally {
    state.busy = false;
  }
}

function detectTransitions(list) {
  for (const t of list) {
    const was = state.prev.get(t.gid);
    if (was && was !== t.status && state.settings.notifications) {
      if (t.status === 'complete' && !t.followedBy) api.notify('اكتمل التحميل', t.name);
      if (t.status === 'error') api.notify('فشل التحميل', `${t.name}\n${t.errorMessage || ''}`);
    }
    state.prev.set(t.gid, t.status);
  }
  const working = list.some((t) => t.status === 'active' || t.status === 'waiting');
  if (state.hadWork && !working && state.settings.shutdownWhenDone && list.some((t) => t.status === 'complete')) {
    api.shutdown();
    toast('سيُطفأ الحاسوب خلال دقيقة لاكتمال التحميلات.', [{ label: 'إلغاء الإطفاء', fn: () => api.abortShutdown() }], 58000);
  }
  state.hadWork = working;
}

function updateGlobal(g) {
  const down = Number(g.downloadSpeed || 0);
  const up = Number(g.uploadSpeed || 0);
  $('#gDown').textContent = fmtSpeed(down);
  $('#gUp').textContent = fmtSpeed(up);
  api.setTray(`وشاح — ↓ ${fmtSpeed(down)}  ↑ ${fmtSpeed(up)}  • نشطة ${g.numActive}`);
  state.spark.push(down);
  if (state.spark.length > 60) state.spark.shift();
  $('#peak').textContent = `الذروة ${fmtSpeed(Math.max(...state.spark))}`;
  drawSpark();
}

function drawSpark() {
  const c = $('#spark');
  const ctx = c.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const w = c.clientWidth;
  const h = c.clientHeight;
  if (c.width !== w * dpr) { c.width = w * dpr; c.height = h * dpr; }
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);
  const d = state.spark;
  if (d.length < 2) return;
  const max = Math.max(1, ...d);
  const step = w / 59;
  const gold = getComputedStyle(document.documentElement).getPropertyValue('--gold').trim();
  ctx.beginPath();
  d.forEach((v, i) => {
    const x = w - (d.length - 1 - i) * step;
    const y = h - 4 - (v / max) * (h - 10);
    i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
  });
  ctx.strokeStyle = gold;
  ctx.lineWidth = 1.6;
  ctx.stroke();
  ctx.lineTo(w, h);
  ctx.lineTo(w - (d.length - 1) * step, h);
  ctx.closePath();
  const grd = ctx.createLinearGradient(0, 0, 0, h);
  grd.addColorStop(0, 'rgba(201,164,92,.35)');
  grd.addColorStop(1, 'rgba(201,164,92,0)');
  ctx.fillStyle = grd;
  ctx.fill();
}

// ——— الرسم ———
function visible() {
  const q = state.q.trim().toLowerCase();
  return state.tasks.filter((t) => {
    if (state.filter !== 'all' && bucket(t.status) !== state.filter) return false;
    if (state.cat !== 'all' && t.cat !== state.cat) return false;
    if (q) {
      const uri = (t.files && t.files[0] && t.files[0].uris && t.files[0].uris[0] && t.files[0].uris[0].uri) || '';
      if (!t.name.toLowerCase().includes(q) && !uri.toLowerCase().includes(q)) return false;
    }
    return true;
  });
}

function render() {
  const counts = { all: state.tasks.length, active: 0, waiting: 0, complete: 0, error: 0 };
  state.tasks.forEach((t) => { counts[bucket(t.status)]++; });
  $$('[data-count]').forEach((el) => { el.textContent = counts[el.dataset.count]; });

  const list = $('#list');
  const items = visible();
  const keep = new Set(items.map((t) => t.gid));
  for (const [gid, el] of state.rows) if (!keep.has(gid)) { el.remove(); state.rows.delete(gid); }
  items.forEach((t, i) => {
    let el = state.rows.get(t.gid);
    if (!el) { el = createRow(t); state.rows.set(t.gid, el); }
    updateRow(el, t);
    if (list.children[i] !== el) list.insertBefore(el, list.children[i] || null);
  });
  $('#empty').hidden = items.length > 0;
}

function createRow(t) {
  const el = document.createElement('div');
  el.className = 'row';
  el.dataset.gid = t.gid;
  el.innerHTML = `
    <div class="file"><div class="glyph"></div><div class="file-text"><div class="name"></div><div class="meta"></div></div></div>
    <div class="prog"><div class="ribbon"><i></i></div><div class="pct"><span class="p1"></span><span class="p2"></span></div></div>
    <div class="speed"><b></b></div>
    <div class="eta num"></div>
    <div class="acts"></div>`;
  return el;
}

function updateRow(el, t) {
  const pct = t.totalLength ? (t.completedLength / t.totalLength) * 100 : 0;
  el.className = `row is-${t.status === 'removed' ? 'error' : t.status}`;
  $('.glyph', el).textContent = t.cat === 'torrent' ? 'BT' : (ext(t.name) || 'FILE').slice(0, 4).toUpperCase();
  $('.name', el).textContent = t.name;
  $('.name', el).title = t.name;
  const bits = [`<span class="st ${t.status}">${STATUS_AR[t.status] || t.status}</span>`];
  if (t.status === 'active') bits.push(`${t.connections} اتصال`);
  if (t.numSeeders) bits.push(`${t.numSeeders} مشارك`);
  if (t.status === 'error' && t.errorMessage) bits.push(esc(t.errorMessage));
  $('.meta', el).innerHTML = bits.join('  |  ');
  $('.ribbon > i', el).style.width = `${pct.toFixed(1)}%`;
  $('.p1', el).textContent = t.totalLength ? `${fmtBytes(t.completedLength)} من ${fmtBytes(t.totalLength)}` : fmtBytes(t.completedLength);
  $('.p2', el).textContent = t.totalLength ? `\u2066${pct.toFixed(1)}%\u2069` : '';
  $('.speed b', el).textContent = t.status === 'active' ? fmtSpeed(t.downloadSpeed) : '—';
  $('.eta', el).textContent = `\u2066${fmtEta(t)}\u2069`;

  const acts = [];
  if (t.status === 'active' || t.status === 'waiting') acts.push(['pause', 'إيقاف مؤقت', ICONS.pause]);
  if (t.status === 'paused') acts.push(['resume', 'استئناف', ICONS.play]);
  if (t.status === 'error' || t.status === 'removed') acts.push(['retry', 'إعادة المحاولة', ICONS.retry]);
  if (t.status === 'complete') acts.push(['open', 'فتح الملف', ICONS.open]);
  acts.push(['folder', 'فتح المجلد', ICONS.folder], ['copy', 'نسخ الرابط', ICONS.link], ['remove', 'حذف', ICONS.trash]);
  const sig = acts.map((a) => a[0]).join();
  const box = $('.acts', el);
  if (box.dataset.sig !== sig) {
    box.dataset.sig = sig;
    box.innerHTML = acts.map(([a, label, icon]) => `<button data-act="${a}" title="${label}" aria-label="${label}" class="${a === 'remove' ? 'danger' : ''}">${icon}</button>`).join('');
  }
}

// ——— الإجراءات ———
function uriOf(t) {
  const f = t.files && t.files[0];
  if (t.infoHash) return `magnet:?xt=urn:btih:${t.infoHash}`;
  return (f && f.uris && f.uris[0] && f.uris[0].uri) || '';
}

async function act(action, t) {
  try {
    if (action === 'pause') await api.rpc('aria2.pause', [t.gid]);
    if (action === 'resume') await api.rpc('aria2.unpause', [t.gid]);
    if (action === 'retry') {
      const uris = (t.files && t.files[0] && t.files[0].uris || []).map((u) => u.uri);
      const u = uris.length ? [...new Set(uris)] : [uriOf(t)];
      await api.rpc('aria2.addUri', [u, { dir: t.dir }]);
      await api.rpc('aria2.removeDownloadResult', [t.gid]);
    }
    if (action === 'open') await api.openPath(taskPath(t));
    if (action === 'folder') await api.showItem(taskPath(t));
    if (action === 'copy') { api.copy(uriOf(t)); toast('نُسخ الرابط'); }
    if (action === 'remove') {
      const r = await ask('حذف المهمة', `«${t.name}»`, 'احذف الملف من القرص أيضاً');
      if (!r.ok) return;
      const running = ['active', 'waiting', 'paused'].includes(t.status);
      if (running) { await api.rpc('aria2.forceRemove', [t.gid]); await sleep(400); }
      await api.rpc('aria2.removeDownloadResult', [t.gid]).catch(() => {});
      if (r.checked) await api.deleteFiles([taskPath(t)]);
    }
  } catch (err) {
    toast(`تعذر التنفيذ: ${err.message}`);
  }
  refresh();
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

$('#list').addEventListener('click', (e) => {
  const btn = e.target.closest('[data-act]');
  if (!btn) return;
  const gid = btn.closest('.row').dataset.gid;
  const t = state.tasks.find((x) => x.gid === gid);
  if (t) act(btn.dataset.act, t);
});
$('#list').addEventListener('dblclick', (e) => {
  const row = e.target.closest('.row');
  const t = row && state.tasks.find((x) => x.gid === row.dataset.gid);
  if (t) act(t.status === 'complete' ? 'open' : t.status === 'paused' ? 'resume' : 'pause', t);
});

// ——— نافذة الإضافة ———
function openAdd(prefill = {}) {
  const d = $('#addDialog');
  switchTab(prefill.torrent ? 'torrent' : 'links');
  $('#urls').value = (prefill.urls || []).join('\n');
  $('#outName').value = prefill.filename || '';
  $('#referer').value = prefill.referer || '';
  $('#cookie').value = prefill.cookie || '';
  $('#ua').value = prefill.userAgent || '';
  $('#user').value = ''; $('#pass').value = ''; $('#taskLimit').value = ''; $('#checksum').value = '';
  $('#mirrors').checked = false;
  $('#startPaused').checked = false;
  $('#dir').value = state.settings.dir || '';
  $('#split').value = state.settings.split || 32;
  $('#splitVal').textContent = $('#split').value;
  state.torrent = prefill.torrent || null;
  $('#torrentName').textContent = state.torrent ? state.torrent.name : 'اختر ملف ‎.torrent أو اسحبه إلى هنا';
  $('.adv').open = !!(prefill.cookie || prefill.referer);
  if (!d.open) d.showModal();
  setTimeout(() => (state.torrent ? $('#confirmAdd') : $('#urls')).focus(), 50);
}
function switchTab(name) {
  $$('.tab').forEach((b) => b.classList.toggle('active', b.dataset.tab === name));
  $$('.tab-pane').forEach((p) => { p.hidden = p.dataset.pane !== name; });
}
$$('.tab').forEach((b) => b.addEventListener('click', () => switchTab(b.dataset.tab)));
$('#split').addEventListener('input', (e) => { $('#splitVal').textContent = e.target.value; });
$('#pickDir').addEventListener('click', async () => { const d = await api.pickDir(); if (d) $('#dir').value = d; });
$('#torrentPick').addEventListener('click', async () => {
  const t = await api.pickTorrent();
  if (t) { state.torrent = t; $('#torrentName').textContent = t.name; }
});
$('#cancelAdd').addEventListener('click', () => $('#addDialog').close());

function buildOptions() {
  const split = Number($('#split').value);
  const o = { split: String(split), 'max-connection-per-server': String(Math.min(16, split)) };
  const dir = $('#dir').value.trim();
  if (dir) o.dir = dir;
  if ($('#referer').value.trim()) o.referer = $('#referer').value.trim();
  if ($('#ua').value.trim()) o['user-agent'] = $('#ua').value.trim();
  const headers = [];
  if ($('#cookie').value.trim()) headers.push(`Cookie: ${$('#cookie').value.trim()}`);
  if (headers.length) o.header = headers;
  if ($('#user').value) { o['http-user'] = $('#user').value; o['ftp-user'] = $('#user').value; }
  if ($('#pass').value) { o['http-passwd'] = $('#pass').value; o['ftp-passwd'] = $('#pass').value; }
  if (Number($('#taskLimit').value) > 0) o['max-download-limit'] = `${Number($('#taskLimit').value)}K`;
  if ($('#checksum').value.trim()) o.checksum = $('#checksum').value.trim();
  if ($('#startPaused').checked) o.pause = 'true';
  return o;
}

$('#addForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const opts = buildOptions();
  const torrentTab = !$('[data-pane="torrent"]').hidden;
  try {
    if (torrentTab) {
      if (!state.torrent) { toast('اختر ملف تورنت أولاً'); return; }
      await api.rpc('aria2.addTorrent', [state.torrent.base64, [], opts]);
    } else {
      const urls = $('#urls').value.split(/\s*\n\s*/).map((s) => s.trim()).filter((s) => /^(https?|ftps?|sftp|magnet):/i.test(s));
      if (!urls.length) { toast('أدخل رابطاً صالحاً يبدأ بـ http أو ftp أو magnet'); return; }
      const out = $('#outName').value.trim();
      if ($('#mirrors').checked) {
        if (out) opts.out = out;
        await api.rpc('aria2.addUri', [urls, opts]);
      } else {
        for (const u of urls) {
          const o = { ...opts };
          if (out && urls.length === 1) o.out = out;
          await api.rpc('aria2.addUri', [[u], o]);
        }
      }
    }
    $('#addDialog').close();
    toast(opts.pause ? 'أُضيفت المهمة متوقفة' : 'بدأ التحميل');
    refresh();
  } catch (err) {
    toast(`تعذرت الإضافة: ${err.message}`);
  }
});

async function quickAdd(p) {
  const opts = { split: String(state.settings.split || 32), 'max-connection-per-server': String(Math.min(16, state.settings.maxConnPerServer || 16)) };
  if (p.filename) opts.out = p.filename;
  if (p.referer) opts.referer = p.referer;
  if (p.userAgent) opts['user-agent'] = p.userAgent;
  if (p.cookie) opts.header = [`Cookie: ${p.cookie}`];
  await api.rpc('aria2.addUri', [p.urls, opts]);
  toast(`بدأ تحميل ${p.filename || 'الملف'} من المتصفح`);
  refresh();
}

api.onExternal((p) => {
  if (p.source === 'clipboard') {
    toast(`رابط في الحافظة: ${p.urls[0]}`, [{ label: 'حمّله', fn: () => openAdd(p) }], 9000);
    return;
  }
  if (p.autoStart && p.urls) { quickAdd(p).catch((err) => toast(err.message)); return; }
  openAdd(p);
});

// ——— أزرار عامة ———
$('#btnAdd').addEventListener('click', () => openAdd());
$('#btnAdd2').addEventListener('click', () => openAdd());
$('#resumeAll').addEventListener('click', () => api.rpc('aria2.unpauseAll').then(refresh));
$('#pauseAll').addEventListener('click', () => api.rpc('aria2.pauseAll').then(refresh));
$('#purge').addEventListener('click', () => api.rpc('aria2.purgeDownloadResult').then(refresh));
$('#q').addEventListener('input', (e) => { state.q = e.target.value; render(); });
$$('[data-win]').forEach((b) => b.addEventListener('click', () => api.win(b.dataset.win)));
$('#statusNav').addEventListener('click', (e) => {
  const b = e.target.closest('[data-filter]');
  if (!b) return;
  state.filter = b.dataset.filter;
  $$('#statusNav .nav-item').forEach((x) => x.classList.toggle('active', x === b));
  showView('tasks');
  render();
});
$('#catNav').addEventListener('click', (e) => {
  const b = e.target.closest('[data-cat]');
  if (!b) return;
  state.cat = b.dataset.cat;
  $$('#catNav .nav-item').forEach((x) => x.classList.toggle('active', x === b));
  showView('tasks');
  render();
});
$('#btnSettings').addEventListener('click', () => showView('settings'));

function showView(v) {
  $('#viewTasks').hidden = v !== 'tasks';
  $('#viewSettings').hidden = v !== 'settings';
  $('#btnSettings').classList.toggle('active', v === 'settings');
  if (v === 'settings') fillSettings();
}

// ——— الإعدادات ———
function getPath(obj, key) { return key.split('.').reduce((o, k) => (o ? o[k] : undefined), obj); }
function setPath(obj, key, val) {
  const parts = key.split('.');
  const last = parts.pop();
  const target = parts.reduce((o, k) => (o[k] = o[k] || {}), obj);
  target[last] = val;
}
function fillSettings() {
  const s = state.settings;
  $$('#settingsForm [name]').forEach((el) => {
    const v = getPath(s, el.name);
    if (el.type === 'checkbox') el.checked = !!v;
    else el.value = v ?? '';
  });
  $('#aboutLine').textContent = `وشاح للتكنولوجيا — الإصدار ${s.version}  |  منفذ المحرك ${s.rpcPort}  |  منفذ الإضافة ${s.bridgePort}`;
}
$('[name="uaPreset"]').addEventListener('change', (e) => {
  if (e.target.value !== 'custom') $('[name="userAgent"]').value = state.settings.uaPresets[e.target.value];
});
$('[name="userAgent"]').addEventListener('input', () => { $('[name="uaPreset"]').value = 'custom'; });
$('[data-pick="dir"]').addEventListener('click', async () => { const d = await api.pickDir(); if (d) $('[name="dir"]').value = d; });
$('#fetchTrackers').addEventListener('click', async () => {
  try { $('[name="trackers"]').value = await api.fetchTrackers(); toast('جُلبت قائمة المتتبعات — احفظ لتطبيقها'); } catch (err) { toast(err.message); }
});
$('#openExt').addEventListener('click', () => api.openExtensionFolder());
$('#saveSettings').addEventListener('click', async () => {
  const patch = { schedule: { ...(state.settings.schedule || {}) } };
  $$('#settingsForm [name]').forEach((el) => {
    let v = el.type === 'checkbox' ? el.checked : el.value;
    if (el.type === 'number') v = Number(v);
    setPath(patch, el.name, v);
  });
  patch.split = Math.max(1, Math.min(64, patch.split));
  patch.maxConnPerServer = Math.max(1, Math.min(16, patch.maxConnPerServer));
  const r = await api.setSettings(patch);
  state.settings = await api.getSettings();
  applyTheme();
  toast(r.ok ? 'حُفظت الإعدادات' : `حُفظت، لكن المحرك رفض بعضها: ${r.error}`);
});

function applyTheme() {
  const t = state.settings.theme;
  const dark = t === 'system' ? matchMedia('(prefers-color-scheme: dark)').matches : t !== 'light';
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
}

// ——— تنبيهات وسؤال ———
function toast(msg, actions = [], ms = 4000) {
  const el = document.createElement('div');
  el.className = 'toast';
  el.innerHTML = `<p>${esc(msg)}</p>`;
  actions.forEach((a) => {
    const b = document.createElement('button');
    b.textContent = a.label;
    b.onclick = () => { a.fn(); el.remove(); };
    el.appendChild(b);
  });
  $('#toasts').appendChild(el);
  setTimeout(() => el.remove(), ms);
}
function ask(title, body, checkLabel) {
  const d = $('#askDialog');
  $('#askTitle').textContent = title;
  $('#askBody').textContent = body;
  $('#askCheckWrap').hidden = !checkLabel;
  $('#askCheckLabel').textContent = checkLabel || '';
  $('#askCheck').checked = false;
  d.showModal();
  return new Promise((resolve) => {
    d.addEventListener('close', () => resolve({ ok: d.returnValue === 'yes', checked: $('#askCheck').checked }), { once: true });
  });
}

// ——— لصق، سحب وإفلات، اختصارات ———
document.addEventListener('keydown', (e) => {
  if (e.ctrlKey && e.key.toLowerCase() === 'n') { e.preventDefault(); openAdd(); }
  if (e.ctrlKey && e.key.toLowerCase() === 'f') { e.preventDefault(); showView('tasks'); $('#q').focus(); }
});
document.addEventListener('paste', (e) => {
  if (e.target.closest('input, textarea') || $('#addDialog').open) return;
  const text = e.clipboardData.getData('text').trim();
  const urls = text.split(/\s+/).filter((s) => /^(https?|ftps?|sftp|magnet):/i.test(s));
  if (urls.length) openAdd({ urls });
});
let dragDepth = 0;
window.addEventListener('dragenter', (e) => { e.preventDefault(); dragDepth++; $('#dropzone').hidden = false; });
window.addEventListener('dragleave', () => { if (--dragDepth <= 0) { dragDepth = 0; $('#dropzone').hidden = true; } });
window.addEventListener('dragover', (e) => e.preventDefault());
window.addEventListener('drop', (e) => {
  e.preventDefault();
  dragDepth = 0;
  $('#dropzone').hidden = true;
  const file = [...e.dataTransfer.files].find((f) => f.name.toLowerCase().endsWith('.torrent'));
  if (file) {
    const reader = new FileReader();
    reader.onload = () => openAdd({ torrent: { name: file.name, base64: String(reader.result).split(',')[1] } });
    reader.readAsDataURL(file);
    return;
  }
  const text = e.dataTransfer.getData('text/uri-list') || e.dataTransfer.getData('text/plain');
  const urls = (text || '').split(/\s+/).filter((s) => /^(https?|ftps?|sftp|magnet):/i.test(s));
  if (urls.length) openAdd({ urls });
});

// ——— الإقلاع ———
(async function init() {
  state.settings = await api.getSettings();
  applyTheme();
  matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);
  api.ready();
  refresh();
  setInterval(refresh, 1000);
})();
