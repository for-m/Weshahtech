package com.wishah.downloader.engine

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** حفظ المهام وأجزائها في ملف JSON ليُستأنف التحميل بعد إغلاق التطبيق */
class TaskStore(private val file: File) {

    fun load(): List<Task> {
        if (!file.exists()) return emptyList()
        return try {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map { i -> fromJson(arr.getJSONObject(i)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun save(tasks: Collection<Task>) {
        val arr = JSONArray()
        tasks.forEach { arr.put(toJson(it)) }
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.writeText(arr.toString())
        tmp.renameTo(file)
    }

    private fun str(o: JSONObject, k: String): String? = if (o.isNull(k)) null else o.optString(k).ifBlank { null }

    private fun fromJson(o: JSONObject): Task {
        val headers = mutableMapOf<String, String>()
        o.optJSONObject("headers")?.let { h -> h.keys().forEach { k -> headers[k] = h.getString(k) } }
        val t = Task(
            id = o.getString("id"),
            url = o.getString("url"),
            fileName = o.getString("name"),
            headers = headers,
            threads = o.optInt("threads", 16),
            autoName = o.optBoolean("autoName"),
            createdAt = o.optLong("createdAt"),
        )
        t.status = runCatching { Status.valueOf(o.getString("status")) }.getOrDefault(Status.PAUSED)
        t.total = o.optLong("total", -1)
        t.resumable = o.optBoolean("resumable")
        t.error = str(o, "error")
        t.savedUri = str(o, "savedUri")
        t.mime = str(o, "mime")
        t.completedAt = o.optLong("completedAt")
        o.optJSONArray("segments")?.let { segs ->
            for (j in 0 until segs.length()) {
                val s = segs.getJSONArray(j)
                t.segments += Segment(s.getLong(0), s.getLong(1), s.getLong(2))
            }
        }
        return t
    }

    private fun toJson(t: Task) = JSONObject().apply {
        put("id", t.id); put("url", t.url); put("name", t.fileName)
        put("headers", JSONObject(t.headers as Map<*, *>))
        put("threads", t.threads); put("autoName", t.autoName); put("createdAt", t.createdAt)
        put("status", t.status.name); put("total", t.total); put("resumable", t.resumable)
        put("error", t.error ?: JSONObject.NULL)
        put("savedUri", t.savedUri ?: JSONObject.NULL)
        put("mime", t.mime ?: JSONObject.NULL)
        put("completedAt", t.completedAt)
        put("segments", JSONArray().apply {
            t.segments.forEach { s -> put(JSONArray().put(s.start).put(s.end).put(s.pos)) }
        })
    }
}
