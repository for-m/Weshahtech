@file:OptIn(ExperimentalMaterial3Api::class)

package com.wishah.downloader.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.wishah.downloader.engine.Downloads
import com.wishah.downloader.engine.Status
import com.wishah.downloader.engine.TaskUi

private val URL_RX = Regex("^https?://\\S+$", RegexOption.IGNORE_CASE)

@Composable
fun WishahRoot(sharedUrl: String?, onSharedConsumed: () -> Unit) {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf("home") }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(Modifier.fillMaxSize().background(Ink)) {
            if (screen == "settings") {
                BackHandler { screen = "home" }
                SettingsScreen(onBack = { screen = "home" })
            } else {
                HomeScreen(sharedUrl, onSharedConsumed, onSettings = { screen = "settings" })
            }
        }
    }
}

// ——— الشاشة الرئيسية ———

@Composable
fun HomeScreen(sharedUrl: String?, onSharedConsumed: () -> Unit, onSettings: () -> Unit) {
    val tasks by Downloads.state.collectAsState()
    var filter by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var prefill by remember { mutableStateOf("") }
    val history = remember { mutableStateListOf<Float>().apply { repeat(60) { add(0f) } } }
    val totalSpeed = tasks.sumOf { it.speed }

    LaunchedEffect(sharedUrl) {
        if (sharedUrl != null) { prefill = sharedUrl; showAdd = true; onSharedConsumed() }
    }
    LaunchedEffect(tasks) {
        history.add(totalSpeed.toFloat())
        if (history.size > 60) history.removeAt(0)
    }

    val filters = listOf("الكل", "جارٍ", "متوقف", "مكتمل", "فشل")
    val shown = tasks.filter {
        when (filter) {
            1 -> it.status == Status.RUNNING || it.status == Status.QUEUED
            2 -> it.status == Status.PAUSED
            3 -> it.status == Status.COMPLETED
            4 -> it.status == Status.FAILED
            else -> true
        }
    }

    Scaffold(
        containerColor = Ink,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { prefill = ""; showAdd = true },
                containerColor = Gold,
                contentColor = Color(0xFF1A1408),
                icon = { Icon(Icons.Rounded.Add, null) },
                text = { Text("تحميل جديد", fontWeight = FontWeight.SemiBold) },
            )
        },
    ) { pad ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item { Header(onSettings) }
            item {
                SpeedPanel(
                    speed = totalSpeed,
                    active = tasks.count { it.status == Status.RUNNING },
                    done = tasks.count { it.status == Status.COMPLETED },
                    history = history,
                )
            }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filters.size) { i ->
                        FilterChip(
                            selected = filter == i,
                            onClick = { filter = i },
                            label = { Text(filters[i]) },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = Ink2, labelColor = Muted,
                                selectedContainerColor = Ink3, selectedLabelColor = GoldHi,
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true, selected = filter == i,
                                borderColor = Rule, selectedBorderColor = Gold,
                            ),
                        )
                    }
                }
            }
            if (shown.isEmpty()) item { EmptyState() }
            items(shown, key = { it.id }) { TaskRow(it) }
        }
    }

    if (showAdd) AddDialog(prefill) { showAdd = false }
}

@Composable
private fun Header(onSettings: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(Ink3).border(1.dp, Rule, RoundedCornerShape(13.dp)),
            contentAlignment = Alignment.Center,
        ) { SashMark(Modifier.size(28.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("وشاح", color = GoldHi, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("للتكنولوجيا", color = Muted, fontSize = 12.sp)
        }
        IconButton(onClick = onSettings) { Icon(Icons.Rounded.Settings, "الإعدادات", tint = Ivory) }
    }
}

/** علامة وشاح: شريط حريري فوق سهم تحميل */
@Composable
fun SashMark(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val silk = Brush.linearGradient(listOf(GoldHi, Gold, GoldLo))
        val band = Path().apply {
            moveTo(w * .08f, h * .22f)
            cubicTo(w * .35f, h * .12f, w * .6f, h * .34f, w * .92f, h * .2f)
            lineTo(w * .92f, h * .36f)
            cubicTo(w * .6f, h * .5f, w * .35f, h * .28f, w * .08f, h * .38f)
            close()
        }
        drawPath(band, silk)
        val arrow = Path().apply {
            moveTo(w * .5f, h * .46f); lineTo(w * .5f, h * .9f)
            moveTo(w * .3f, h * .7f); lineTo(w * .5f, h * .9f); lineTo(w * .7f, h * .7f)
        }
        drawPath(arrow, silk, style = Stroke(width = w * .1f, cap = StrokeCap.Round))
    }
}

@Composable
private fun SpeedPanel(speed: Long, active: Int, done: Int, history: List<Float>) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Ink2)
            .border(1.dp, Rule, RoundedCornerShape(20.dp)).padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Column(Modifier.weight(1f)) {
                Text("السرعة الآن", color = Muted, fontSize = 12.sp)
                Text(fmtSpeed(speed), color = Ivory, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("$active نشط", color = GoldHi, fontSize = 13.sp)
                Text("$done مكتمل", color = Muted, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        Canvas(Modifier.fillMaxWidth().height(54.dp)) {
            if (history.size < 2) return@Canvas
            val max = (history.maxOrNull() ?: 1f).coerceAtLeast(1f)
            val step = size.width / (history.size - 1)
            val line = Path()
            history.forEachIndexed { i, v ->
                val x = i * step
                val y = size.height - 2f - v / max * (size.height - 6f)
                if (i == 0) line.moveTo(x, y) else line.lineTo(x, y)
            }
            val fill = Path().apply {
                addPath(line); lineTo(size.width, size.height); lineTo(0f, size.height); close()
            }
            drawPath(fill, Brush.verticalGradient(listOf(Gold.copy(alpha = .32f), Color.Transparent)))
            drawPath(line, Gold, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round))
        }
    }
}

@Composable
private fun EmptyState() {
    Column(Modifier.fillMaxWidth().padding(vertical = 48.dp, horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("لا توجد تحميلات هنا", color = Ivory, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text(
            "اضغط «تحميل جديد»، أو شارك أي رابط من المتصفح واختر وشاح.",
            color = Muted, fontSize = 13.sp,
        )
    }
}

// ——— بطاقة المهمة ———

@Composable
private fun TaskRow(t: TaskUi) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var confirm by remember { mutableStateOf(false) }
    val progress = if (t.total > 0) (t.done.toFloat() / t.total).coerceIn(0f, 1f) else 0f

    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Ink2)
            .border(1.dp, Rule, RoundedCornerShape(16.dp)).padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(40.dp).clip(RoundedCornerShape(11.dp)).background(Ink3),
                contentAlignment = Alignment.Center,
            ) { Icon(iconFor(t.name), null, tint = GoldHi, modifier = Modifier.size(22.dp)) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(t.name, color = Ivory, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val (label, color) = statusLabel(t)
                Text(label, color = color, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Spacer(Modifier.height(12.dp))
        Ribbon(progress, t.status)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    if (t.total > 0) "${fmtBytes(t.done)} من ${fmtBytes(t.total)}" else fmtBytes(t.done),
                    color = Muted, fontSize = 12.sp,
                )
                if (t.status == Status.RUNNING) {
                    Text(
                        "${fmtSpeed(t.speed)}   المتبقي ${fmtEta(t.total - t.done, t.speed)}",
                        color = Ivory, fontSize = 12.sp,
                    )
                }
            }
            when (t.status) {
                Status.RUNNING, Status.QUEUED -> Act(Icons.Rounded.Pause, "إيقاف مؤقت") { Downloads.pause(t.id) }
                Status.PAUSED -> Act(Icons.Rounded.PlayArrow, "استئناف") { Downloads.resume(t.id) }
                Status.FAILED -> Act(Icons.Rounded.Refresh, "إعادة المحاولة") { Downloads.resume(t.id) }
                Status.COMPLETED -> {
                    Act(Icons.Rounded.OpenInNew, "فتح") { openFile(ctx, t) }
                    Act(Icons.Rounded.Share, "مشاركة") { shareFile(ctx, t) }
                }
            }
            Act(Icons.Rounded.Link, "نسخ الرابط") {
                clip.setText(AnnotatedString(t.url))
                Toast.makeText(ctx, "نُسخ الرابط", Toast.LENGTH_SHORT).show()
            }
            Act(Icons.Rounded.Delete, "حذف", tint = Garnet) { confirm = true }
        }
    }

    if (confirm) DeleteDialog(t, onDismiss = { confirm = false })
}

@Composable
private fun Act(icon: ImageVector, label: String, tint: Color = Ivory, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(40.dp)) { Icon(icon, label, tint = tint, modifier = Modifier.size(20.dp)) }
}

/** شريط التقدم على هيئة وشاح منسوج يلمع أثناء التحميل */
@Composable
private fun Ribbon(progress: Float, status: Status) {
    val animated by animateFloatAsState(progress, label = "progress")
    val shimmer by rememberInfiniteTransition(label = "weave").animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "x",
    )
    val colors = when (status) {
        Status.COMPLETED -> listOf(Color(0xFF2B7A5A), Jade)
        Status.FAILED -> listOf(Garnet, Garnet)
        Status.PAUSED -> listOf(Sky.copy(alpha = .6f), Sky)
        else -> listOf(GoldLo, Gold, GoldHi)
    }
    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(Ink3)) {
        Box(
            Modifier.fillMaxHeight().fillMaxWidth(animated).clip(RoundedCornerShape(50)).drawBehind {
                drawRect(Brush.horizontalGradient(colors))
                if (status == Status.RUNNING) {
                    val x = shimmer * size.width * 1.6f - size.width * .3f
                    drawRect(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, Color.White.copy(alpha = .45f), Color.Transparent),
                            startX = x - 70f, endX = x + 70f,
                        ),
                    )
                }
            },
        )
    }
}

private fun statusLabel(t: TaskUi): Pair<String, Color> = when (t.status) {
    Status.RUNNING -> (if (t.parts > 0) "يُحمَّل عبر ${t.parts} اتصال" else "يتصل بالخادم…") to GoldHi
    Status.QUEUED -> "في قائمة الانتظار" to Sky
    Status.PAUSED -> (if (t.resumable || t.done == 0L) "متوقف مؤقتاً" else "متوقف — الخادم لا يدعم الاستئناف") to Sky
    Status.COMPLETED -> "مكتمل — في Download/Wishah" to Jade
    Status.FAILED -> "فشل: ${t.error ?: "خطأ غير معروف"}" to Garnet
}

private fun iconFor(name: String): ImageVector = when (categoryOf(name)) {
    Category.VIDEO -> Icons.Rounded.Movie
    Category.AUDIO -> Icons.Rounded.MusicNote
    Category.DOC -> Icons.Rounded.Description
    Category.ARCHIVE -> Icons.Rounded.FolderZip
    Category.APP -> Icons.Rounded.Android
    Category.IMAGE -> Icons.Rounded.Image
    Category.OTHER -> Icons.Rounded.InsertDriveFile
}

private fun openFile(ctx: Context, t: TaskUi) {
    val uri = t.savedUri?.let(Uri::parse) ?: return
    val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, t.mime ?: "*/*")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { ctx.startActivity(Intent.createChooser(intent, "فتح بواسطة").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        .onFailure { Toast.makeText(ctx, "لا يوجد تطبيق يفتح هذا الملف", Toast.LENGTH_SHORT).show() }
}

private fun shareFile(ctx: Context, t: TaskUi) {
    val uri = t.savedUri?.let(Uri::parse) ?: return
    val intent = Intent(Intent.ACTION_SEND).setType(t.mime ?: "*/*").putExtra(Intent.EXTRA_STREAM, uri)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    runCatching { ctx.startActivity(Intent.createChooser(intent, "مشاركة").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

@Composable
private fun DeleteDialog(t: TaskUi, onDismiss: () -> Unit) {
    var withFile by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Ink2,
        title = { Text("حذف المهمة", color = GoldHi) },
        text = {
            Column {
                Text(t.name, color = Ivory, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (t.savedUri != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(withFile, { withFile = it }, colors = CheckboxDefaults.colors(checkedColor = Gold))
                        Text("احذف الملف من الجهاز أيضاً", color = Muted)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { Downloads.remove(t.id, withFile); onDismiss() },
                colors = ButtonDefaults.buttonColors(containerColor = Garnet),
            ) { Text("حذف") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء", color = Ivory) } },
    )
}

// ——— نافذة الإضافة ———

@Composable
fun AddDialog(prefill: String, onDismiss: () -> Unit) {
    val clip = LocalClipboardManager.current
    val initial = remember {
        prefill.ifBlank { clip.getText()?.text?.trim()?.takeIf { URL_RX.matches(it) } ?: "" }
    }
    var urls by remember { mutableStateOf(initial) }
    var name by remember { mutableStateOf("") }
    var threads by remember { mutableFloatStateOf(Downloads.prefs.threads.toFloat()) }
    var advanced by remember { mutableStateOf(false) }
    var referer by remember { mutableStateOf("") }
    var ua by remember { mutableStateOf("") }
    var cookie by remember { mutableStateOf("") }
    val list = urls.lines().map { it.trim() }.filter { URL_RX.matches(it) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Ink2,
        title = { Text("تحميل جديد", color = GoldHi, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = urls, onValueChange = { urls = it },
                    label = { Text("الرابط — رابط في كل سطر") },
                    minLines = 2, maxLines = 6, colors = goldFieldColors(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier.fillMaxWidth(),
                )
                if (list.size <= 1) {
                    OutlinedTextField(
                        value = name, onValueChange = { name = it },
                        label = { Text("اسم الملف (اختياري)") },
                        singleLine = true, colors = goldFieldColors(), modifier = Modifier.fillMaxWidth(),
                    )
                }
                Text("عدد الاتصالات: ${threads.toInt()}", color = Ivory, fontSize = 13.sp)
                Slider(
                    value = threads, onValueChange = { threads = it }, valueRange = 1f..32f, steps = 30,
                    colors = SliderDefaults.colors(thumbColor = GoldHi, activeTrackColor = Gold, inactiveTrackColor = Ink3),
                )
                TextButton(onClick = { advanced = !advanced }) {
                    Text(if (advanced) "إخفاء الخيارات المتقدمة" else "خيارات متقدمة", color = Gold)
                }
                if (advanced) {
                    OutlinedTextField(referer, { referer = it }, label = { Text("المُحيل (Referer)") }, singleLine = true, colors = goldFieldColors(), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(ua, { ua = it }, label = { Text("User-Agent") }, singleLine = true, colors = goldFieldColors(), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(cookie, { cookie = it }, label = { Text("الكوكيز") }, singleLine = true, colors = goldFieldColors(), modifier = Modifier.fillMaxWidth())
                }
            }
        },
        confirmButton = {
            Button(
                enabled = list.isNotEmpty(),
                onClick = {
                    val headers = buildMap {
                        if (referer.isNotBlank()) put("Referer", referer.trim())
                        if (ua.isNotBlank()) put("User-Agent", ua.trim())
                        if (cookie.isNotBlank()) put("Cookie", cookie.trim())
                    }
                    list.forEach { Downloads.add(it, if (list.size == 1) name else null, threads.toInt(), headers) }
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF1A1408)),
            ) { Text(if (list.size > 1) "حمّل ${list.size} ملفات" else "ابدأ التحميل", fontWeight = FontWeight.SemiBold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء", color = Ivory) } },
    )
}

// ——— الإعدادات ———

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val p = Downloads.prefs
    var concurrent by remember { mutableFloatStateOf(p.maxConcurrent.toFloat()) }
    var threads by remember { mutableFloatStateOf(p.threads.toFloat()) }
    var limit by remember { mutableStateOf(if (p.speedLimitKb > 0) p.speedLimitKb.toString() else "") }
    var wifi by remember { mutableStateOf(p.wifiOnly) }
    var ua by remember { mutableStateOf(p.userAgent) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع", tint = Ivory) }
            Text("الإعدادات", color = GoldHi, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))

        Section("التحميل") {
            Text("المهام المتزامنة: ${concurrent.toInt()}", color = Ivory)
            Slider(
                concurrent, { concurrent = it; p.maxConcurrent = it.toInt() }, valueRange = 1f..10f, steps = 8,
                colors = SliderDefaults.colors(thumbColor = GoldHi, activeTrackColor = Gold, inactiveTrackColor = Ink3),
            )
            Text("الاتصالات الافتراضية لكل ملف: ${threads.toInt()}", color = Ivory)
            Slider(
                threads, { threads = it; p.threads = it.toInt() }, valueRange = 1f..32f, steps = 30,
                colors = SliderDefaults.colors(thumbColor = GoldHi, activeTrackColor = Gold, inactiveTrackColor = Ink3),
            )
            OutlinedTextField(
                value = limit,
                onValueChange = { v ->
                    limit = v.filter { it.isDigit() }.take(7)
                    Downloads.setSpeedLimit(limit.toLongOrNull() ?: 0)
                },
                label = { Text("حد السرعة KB/s — فارغ يعني بلا حد") },
                singleLine = true, colors = goldFieldColors(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Section("الشبكة") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("التحميل عبر Wi-Fi فقط", color = Ivory, modifier = Modifier.weight(1f))
                Switch(
                    wifi, { wifi = it; p.wifiOnly = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = GoldHi, checkedTrackColor = GoldLo),
                )
            }
            OutlinedTextField(
                value = ua, onValueChange = { ua = it; p.userAgent = it.ifBlank { com.wishah.downloader.engine.Prefs.DEFAULT_UA } },
                label = { Text("هوية المتصفح (User-Agent)") }, colors = goldFieldColors(), modifier = Modifier.fillMaxWidth(),
            )
        }
        Section("المهام") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { Downloads.resumeAll() }) { Text("استئناف الكل", color = Gold) }
                TextButton(onClick = { Downloads.pauseAll() }) { Text("إيقاف الكل", color = Gold) }
                TextButton(onClick = { Downloads.clearCompleted() }) { Text("مسح المكتملة", color = Gold) }
            }
        }
        Section("حول") {
            Text("وشاح للتكنولوجيا — الإصدار 1.0.0", color = Ivory)
            Text("تُحفظ الملفات في مجلد Download/Wishah.", color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(RoundedCornerShape(18.dp)).background(Ink2)
            .border(1.dp, Rule, RoundedCornerShape(18.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(title, color = Gold, fontWeight = FontWeight.SemiBold)
        content()
    }
}
