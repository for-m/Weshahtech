package com.wishah.downloader

import android.app.Application
import com.wishah.downloader.engine.Downloads
import com.wishah.downloader.service.Notifier

class WishahApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifier.channels(this)
        Downloads.init(this)
    }
}
