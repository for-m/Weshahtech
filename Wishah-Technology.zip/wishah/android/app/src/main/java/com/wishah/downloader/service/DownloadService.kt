package com.wishah.downloader.service

import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.wishah.downloader.R
import com.wishah.downloader.engine.Downloads
import com.wishah.downloader.engine.Status
import com.wishah.downloader.engine.TaskUi
import com.wishah.downloader.ui.fmtBytes
import com.wishah.downloader.ui.fmtSpeed
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** خدمة أمامية تُبقي التحميل حياً والتطبيق في الخلفية */
class DownloadService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Downloads.init(this)
        Notifier.channels(this)
        startForeground(Notifier.ID_PROGRESS, build(emptyList()), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        scope.launch {
            Downloads.state.collect { list ->
                if (Downloads.activeCount() == 0) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                } else {
                    getSystemService(NotificationManager::class.java)
                        .notify(Notifier.ID_PROGRESS, build(list.filter { it.status == Status.RUNNING || it.status == Status.QUEUED }))
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_PAUSE_ALL) Downloads.pauseAll()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun build(active: List<TaskUi>): android.app.Notification {
        val speed = active.sumOf { it.speed }
        val total = active.sumOf { maxOf(it.total, 0L) }
        val done = active.sumOf { it.done }
        val pauseIntent = PendingIntent.getService(
            this, 1,
            Intent(this, DownloadService::class.java).setAction(ACTION_PAUSE_ALL),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val b = NotificationCompat.Builder(this, Notifier.CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_stat)
            .setColor(0xFFC9A45C.toInt())
            .setContentTitle(if (active.size == 1) active[0].name else "وشاح يحمّل ${active.size} ملفات")
            .setContentText("${fmtSpeed(speed)}  •  ${fmtBytes(done)} من ${if (total > 0) fmtBytes(total) else "؟"}")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setContentIntent(Notifier.openApp(this))
            .addAction(0, "إيقاف الكل", pauseIntent)
        if (total > 0) b.setProgress(1000, ((done * 1000) / total).toInt(), false)
        else b.setProgress(0, 0, active.isNotEmpty())
        return b.build()
    }

    companion object {
        const val ACTION_PAUSE_ALL = "com.wishah.downloader.PAUSE_ALL"
    }
}
