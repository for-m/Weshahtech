package com.wishah.downloader.engine

import kotlinx.coroutines.Job
import okhttp3.Call
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicLong

enum class Status { QUEUED, RUNNING, PAUSED, COMPLETED, FAILED }

/** جزء من الملف: من start إلى end، و pos هو البايت التالي المطلوب كتابته */
class Segment(val start: Long, @Volatile var end: Long, @Volatile var pos: Long) {
    @Volatile var busy = false
    val done: Boolean get() = end >= 0 && pos > end
    val remaining: Long get() = if (end < 0) Long.MAX_VALUE else end - pos + 1
}

class Task(
    val id: String,
    val url: String,
    @Volatile var fileName: String,
    val headers: Map<String, String>,
    var threads: Int,
    var autoName: Boolean,
    val createdAt: Long,
) {
    @Volatile var status = Status.QUEUED
    @Volatile var total = -1L
    @Volatile var resumable = false
    @Volatile var error: String? = null
    @Volatile var savedUri: String? = null
    @Volatile var mime: String? = null
    @Volatile var speed = 0L
    var completedAt = 0L
    val segments = CopyOnWriteArrayList<Segment>()
    val tick = AtomicLong()
    var job: Job? = null
    val calls = mutableSetOf<Call>()

    val downloaded: Long get() = segments.sumOf { (it.pos - it.start).coerceAtLeast(0) }

    fun ui() = TaskUi(
        id = id, url = url, name = fileName, total = total,
        done = if (status == Status.COMPLETED && total > 0) total else downloaded,
        speed = if (status == Status.RUNNING) speed else 0,
        status = status, error = error, savedUri = savedUri, mime = mime,
        parts = segments.count { it.busy }, resumable = resumable, createdAt = createdAt,
    )
}

data class TaskUi(
    val id: String,
    val url: String,
    val name: String,
    val total: Long,
    val done: Long,
    val speed: Long,
    val status: Status,
    val error: String?,
    val savedUri: String?,
    val mime: String?,
    val parts: Int,
    val resumable: Boolean,
    val createdAt: Long,
)
