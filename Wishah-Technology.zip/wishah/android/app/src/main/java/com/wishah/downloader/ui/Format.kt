package com.wishah.downloader.ui

import java.util.Locale

fun fmtBytes(v: Long): String {
    var n = v.toDouble().coerceAtLeast(0.0)
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var i = 0
    while (n >= 1024 && i < units.size - 1) { n /= 1024; i++ }
    val digits = if (i == 0) 0 else if (n < 10) 2 else if (n < 100) 1 else 0
    return "\u2066" + String.format(Locale.US, "%.${digits}f %s", n, units[i]) + "\u2069"
}

fun fmtSpeed(v: Long): String = "\u2066${fmtBytes(v)}/s\u2069"

fun fmtEta(left: Long, speed: Long): String {
    if (speed <= 0 || left <= 0) return "—"
    var s = left / speed
    val h = s / 3600; s -= h * 3600
    val m = s / 60; s -= m * 60
    if (h > 99) return "أكثر من يوم"
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%d:%02d", m, s)
}

enum class Category { VIDEO, AUDIO, DOC, ARCHIVE, APP, IMAGE, OTHER }

fun categoryOf(name: String): Category {
    val e = name.substringAfterLast('.', "").lowercase()
    return when (e) {
        "mp4", "mkv", "avi", "mov", "webm", "flv", "m4v", "3gp", "ts" -> Category.VIDEO
        "mp3", "flac", "wav", "aac", "m4a", "ogg", "opus" -> Category.AUDIO
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "epub" -> Category.DOC
        "zip", "rar", "7z", "tar", "gz", "bz2", "xz", "iso" -> Category.ARCHIVE
        "apk", "xapk", "exe", "msi", "dmg", "deb" -> Category.APP
        "jpg", "jpeg", "png", "gif", "webp", "svg", "heic", "avif" -> Category.IMAGE
        else -> Category.OTHER
    }
}
