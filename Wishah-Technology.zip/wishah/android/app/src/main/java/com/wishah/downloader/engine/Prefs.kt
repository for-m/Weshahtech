package com.wishah.downloader.engine

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("wishah", Context.MODE_PRIVATE)

    var maxConcurrent: Int
        get() = sp.getInt("maxConcurrent", 3)
        set(v) = sp.edit().putInt("maxConcurrent", v).apply()

    var threads: Int
        get() = sp.getInt("threads", 16)
        set(v) = sp.edit().putInt("threads", v).apply()

    var speedLimitKb: Long
        get() = sp.getLong("speedLimitKb", 0)
        set(v) = sp.edit().putLong("speedLimitKb", v).apply()

    var wifiOnly: Boolean
        get() = sp.getBoolean("wifiOnly", false)
        set(v) = sp.edit().putBoolean("wifiOnly", v).apply()

    var userAgent: String
        get() = sp.getString("userAgent", DEFAULT_UA) ?: DEFAULT_UA
        set(v) = sp.edit().putString("userAgent", v).apply()

    companion object {
        const val DEFAULT_UA =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36"
    }
}
