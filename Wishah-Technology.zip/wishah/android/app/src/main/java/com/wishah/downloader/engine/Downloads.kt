package com.wishah.downloader.engine

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.core.content.ContextCompat
import com.wishah.downloader.service.DownloadService
import com.wishah.downloader.service.Notifier
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * محرك وشاح:
 * - تقسيم الملف إلى أجزاء تُحمَّل بالتوازي (حتى 32 اتصالاً)
 * - تقسيم ديناميكي: الاتصال الذي ينهي جزأه يأخذ نصف أكبر جزء متبقٍ
 * - استئناف بعد الإيقاف أو إغلاق التطبيق، وإعادة محاولة تلقائية
 * - محدد سرعة عام، وقائمة انتظار بعدد مهام متزامنة قابل للضبط
 */
object Downloads {
    private const val MIN_SPLIT = 1L shl 20
    private const val MAX_RETRIES = 8

    private lateinit var app: Context
    private lateinit var store: TaskStore
    lateinit var prefs: Prefs
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val tasks = LinkedHashMap<String, Task>()
    private val lock = Any()
    private val _state = MutableStateFlow<List<TaskUi>>(emptyList())
    val state: StateFlow<List<TaskUi>> = _state.asStateFlow()
    val limiter = RateLimiter()
    private var initialized = false

    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .build()
    }

    @Synchronized
    fun init(context: Context) {
        if (initialized) return
        initialized = true
        app = context.applicationContext
        prefs = Prefs(app)
        store = TaskStore(File(app.filesDir, "tasks.json"))
        limiter.bytesPerSec = prefs.speedLimitKb * 1024
        store.load().forEach { t ->
            if (t.status == Status.RUNNING) t.status = Status.QUEUED
            tasks[t.id] = t
        }
        publish()
        scope.launch { ticker() }
    }

    // ——— واجهة الاستخدام ———

    fun add(url: String, name: String?, threads: Int, headers: Map<String, String>) {
        val clean = name?.trim()?.takeUnless { it.isBlank() }
        val t = Task(
            id = UUID.randomUUID().toString(),
            url = url.trim(),
            fileName = clean ?: guessName(null, url, null),
            headers = headers,
            threads = threads.coerceIn(1, 32),
            autoName = clean == null,
            createdAt = System.currentTimeMillis(),
        )
        synchronized(lock) { tasks[t.id] = t }
        persist()
        schedule()
        publish()
    }

    fun pause(id: String) {
        val t = synchronized(lock) { tasks[id] } ?: return
        if (t.status == Status.RUNNING || t.status == Status.QUEUED) {
            t.status = Status.PAUSED
            cancel(t)
        }
        persist(); publish()
    }

    fun resume(id: String) {
        val t = synchronized(lock) { tasks[id] } ?: return
        if (t.status == Status.PAUSED || t.status == Status.FAILED) {
            t.status = Status.QUEUED
            t.error = null
        }
        schedule(); publish()
    }

    fun remove(id: String, deleteFile: Boolean) {
        val t = synchronized(lock) { tasks.remove(id) } ?: return
        t.status = Status.PAUSED
        cancel(t)
        partFile(t).delete()
        if (deleteFile) t.savedUri?.let { runCatching { app.contentResolver.delete(Uri.parse(it), null, null) } }
        persist(); publish()
    }

    fun pauseAll() = snapshot().forEach { pause(it.id) }

    fun resumeAll() = snapshot().forEach { resume(it.id) }

    fun clearCompleted() {
        synchronized(lock) { tasks.values.removeAll { it.status == Status.COMPLETED } }
        persist(); publish()
    }

    fun setSpeedLimit(kb: Long) {
        prefs.speedLimitKb = kb
        limiter.bytesPerSec = kb * 1024
    }

    fun activeCount(): Int = synchronized(lock) {
        tasks.values.count { it.status == Status.RUNNING || it.status == Status.QUEUED }
    }

    // ——— الجدولة ———

    private fun snapshot(): List<Task> = synchronized(lock) { tasks.values.toList() }

    private fun cancel(t: Task) {
        t.job?.cancel()
        synchronized(t.calls) { t.calls.forEach { it.cancel() } }
    }

    private suspend fun ticker() {
        var n = 0
        while (true) {
            snapshot().forEach { t ->
                val b = t.tick.getAndSet(0)
                t.speed = if (t.status == Status.RUNNING) (t.speed * 0.35 + b * 0.65).toLong() else 0
            }
            schedule()
            publish()
            if (++n % 3 == 0) persist()
            delay(1000)
        }
    }

    private fun schedule() {
        if (prefs.wifiOnly && isMetered()) return
        val toStart = mutableListOf<Task>()
        synchronized(lock) {
            var running = tasks.values.count { it.status == Status.RUNNING }
            for (t in tasks.values) {
                if (running >= prefs.maxConcurrent) break
                if (t.status == Status.QUEUED) {
                    t.status = Status.RUNNING
                    running++
                    toStart += t
                }
            }
        }
        if (toStart.isEmpty()) return
        publish()
        toStart.forEach { t -> t.job = scope.launch { run(t) } }
        runCatching { ContextCompat.startForegroundService(app, Intent(app, DownloadService::class.java)) }
    }

    private fun isMetered(): Boolean =
        app.getSystemService(ConnectivityManager::class.java)?.isActiveNetworkMetered ?: false

    private fun publish() {
        _state.value = snapshot().map { it.ui() }.sortedByDescending { it.createdAt }
    }

    private fun persist() = runCatching { store.save(snapshot()) }

    private fun partFile(t: Task): File {
        val dir = File(app.getExternalFilesDir(null) ?: app.filesDir, "parts").apply { mkdirs() }
        return File(dir, "${t.id}.part")
    }

    // ——— التنفيذ ———

    private suspend fun run(t: Task) {
        try {
            t.error = null
            if (t.segments.isEmpty()) probe(t)
            else if (!t.resumable) t.segments.forEach { synchronized(it) { it.pos = it.start } }

            val part = partFile(t)
            RandomAccessFile(part, "rw").use { raf ->
                if (!t.resumable) raf.setLength(0)
                if (t.total > 0 && raf.length() != t.total) raf.setLength(t.total)
                val channel = raf.channel
                val workers = if (t.resumable) t.threads else 1
                coroutineScope {
                    repeat(workers) { launch { worker(t, channel) } }
                }
            }
            if (t.total <= 0) t.total = part.length()
            finalize(t, part)
            t.status = Status.COMPLETED
            t.completedAt = System.currentTimeMillis()
            Notifier.finished(app, t.fileName, true)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (t.status == Status.RUNNING) {
                t.status = Status.FAILED
                t.error = e.message ?: e.javaClass.simpleName
                Notifier.finished(app, t.fileName, false)
            }
        } finally {
            synchronized(t.calls) { t.calls.clear() }
            t.segments.forEach { it.busy = false }
            persist()
            publish()
        }
    }

    private suspend fun worker(t: Task, channel: FileChannel) {
        while (true) {
            currentCoroutineContext().ensureActive()
            val seg = nextSegment(t) ?: return
            try {
                fetchSegment(t, seg, channel)
            } finally {
                seg.busy = false
            }
        }
    }

    /** يعطي الاتصال جزءاً حراً، أو يقسم أكبر جزء قيد التحميل إلى نصفين */
    private fun nextSegment(t: Task): Segment? {
        synchronized(t) {
            val free = t.segments.firstOrNull { !it.busy && !it.done }
            if (free != null) {
                free.busy = true
                return free
            }
            if (!t.resumable) return null
            val victim = t.segments.filter { it.busy && !it.done }.maxByOrNull { it.remaining } ?: return null
            synchronized(victim) {
                if (victim.remaining < 2 * MIN_SPLIT) return null
                val mid = victim.pos + victim.remaining / 2
                val fresh = Segment(mid + 1, victim.end, mid + 1)
                fresh.busy = true
                victim.end = mid
                t.segments += fresh
                return fresh
            }
        }
    }

    private suspend fun fetchSegment(t: Task, seg: Segment, channel: FileChannel) {
        var attempt = 0
        val buf = ByteArray(64 * 1024)
        while (true) {
            currentCoroutineContext().ensureActive()
            if (seg.done) return
            val from = seg.pos
            val to = seg.end
            val rb = Request.Builder().url(t.url)
            applyHeaders(rb, t)
            if (t.resumable) rb.header("Range", "bytes=$from-$to")
            val call = client.newCall(rb.build())
            synchronized(t.calls) { t.calls += call }
            try {
                call.execute().use { resp ->
                    if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
                    if (t.resumable && resp.code != 206) throw IOException("الخادم رفض طلب الجزء")
                    val input = resp.body?.byteStream() ?: throw IOException("استجابة فارغة")
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        limiter.acquire(n)
                        val allowed = synchronized(seg) {
                            if (seg.end < 0) n.toLong() else minOf(n.toLong(), seg.end - seg.pos + 1)
                        }.toInt()
                        if (allowed > 0) {
                            val bb = ByteBuffer.wrap(buf, 0, allowed)
                            var off = seg.pos
                            while (bb.hasRemaining()) off += channel.write(bb, off)
                            synchronized(seg) { seg.pos += allowed }
                            t.tick.addAndGet(allowed.toLong())
                            attempt = 0
                        }
                        if (allowed < n) return // قُسم الجزء وأخذ اتصال آخر بقيته
                    }
                }
                if (seg.end < 0) {
                    t.total = seg.pos
                    seg.end = seg.pos - 1
                    return
                }
                if (seg.done) return
                throw IOException("انقطع الاتصال قبل اكتمال الجزء")
            } catch (e: IOException) {
                currentCoroutineContext().ensureActive()
                if (!t.resumable) synchronized(seg) { seg.pos = seg.start }
                if (++attempt > MAX_RETRIES) throw e
                delay(minOf(30_000L, 1_500L * attempt))
            } finally {
                synchronized(t.calls) { t.calls -= call }
            }
        }
    }

    private fun applyHeaders(rb: Request.Builder, t: Task) {
        t.headers.forEach { (k, v) -> if (v.isNotBlank()) rb.header(k, v) }
        if (t.headers.keys.none { it.equals("User-Agent", true) }) rb.header("User-Agent", prefs.userAgent)
    }

    /** يكتشف حجم الملف واسمه ودعم الاستئناف، ثم يقسمه إلى أجزاء */
    private fun probe(t: Task) {
        val rb = Request.Builder().url(t.url).header("Range", "bytes=0-0")
        applyHeaders(rb, t)
        client.newCall(rb.build()).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            if (r.code == 206) {
                t.total = r.header("Content-Range")?.substringAfterLast('/')?.trim()?.toLongOrNull() ?: -1L
                t.resumable = t.total > 0
            } else {
                t.total = r.body?.contentLength() ?: -1L
                t.resumable = false
            }
            val type = r.header("Content-Type")
            t.mime = type?.substringBefore(';')?.trim()
            if (t.autoName) t.fileName = guessName(r.header("Content-Disposition"), r.request.url.toString(), type)
        }
        t.segments.clear()
        if (t.resumable) {
            val n = if (t.total >= 2 * MIN_SPLIT) t.threads.coerceIn(1, 32) else 1
            val size = t.total / n
            for (i in 0 until n) {
                val s = i * size
                val e = if (i == n - 1) t.total - 1 else s + size - 1
                t.segments += Segment(s, e, s)
            }
        } else {
            t.segments += Segment(0, if (t.total > 0) t.total - 1 else -1, 0)
        }
    }

    private fun guessName(cd: String?, url: String, contentType: String?): String {
        var name: String? = null
        if (cd != null) {
            val star = Regex("filename\\*\\s*=\\s*(?:UTF-8|utf-8)''([^;]+)").find(cd)
            if (star != null) name = runCatching { URLDecoder.decode(star.groupValues[1], "UTF-8") }.getOrNull()
            if (name.isNullOrBlank()) name = Regex("filename\\s*=\\s*\"?([^\";]+)\"?").find(cd)?.groupValues?.get(1)
        }
        if (name.isNullOrBlank()) {
            val last = url.substringBefore('?').substringBefore('#').trimEnd('/').substringAfterLast('/')
            name = runCatching { URLDecoder.decode(last, "UTF-8") }.getOrDefault(last)
        }
        var n = (name ?: "").replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
        if (n.isBlank() || n.contains("://")) n = "wishah_${System.currentTimeMillis()}"
        if (!n.contains('.') && contentType != null) {
            MimeTypeMap.getSingleton().getExtensionFromMimeType(contentType.substringBefore(';').trim())?.let { n += ".$it" }
        }
        return n.take(150)
    }

    /** ينقل الملف المكتمل إلى مجلد التنزيلات العام: Download/Wishah */
    private fun finalize(t: Task, part: File) {
        val resolver = app.contentResolver
        val ext = t.fileName.substringAfterLast('.', "").lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: t.mime?.takeIf { it.isNotBlank() }
            ?: "application/octet-stream"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, t.fileName)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Wishah")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("تعذر إنشاء الملف في مجلد التنزيلات")
        try {
            val out = resolver.openOutputStream(uri) ?: throw IOException("تعذر الكتابة في التنزيلات")
            out.use { o -> part.inputStream().use { it.copyTo(o, 256 * 1024) } }
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        resolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
        part.delete()
        t.savedUri = uri.toString()
        t.mime = mime
    }
}
