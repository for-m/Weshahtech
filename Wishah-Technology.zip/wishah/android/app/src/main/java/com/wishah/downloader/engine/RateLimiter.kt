package com.wishah.downloader.engine

import kotlinx.coroutines.delay

/** محدد سرعة عام بأسلوب دلو الرموز، يتشاركه كل الاتصالات */
class RateLimiter {
    @Volatile var bytesPerSec: Long = 0
    private var available = 0.0
    private var last = System.nanoTime()

    suspend fun acquire(n: Int) {
        while (true) {
            val rate = bytesPerSec
            if (rate <= 0) return
            val wait = synchronized(this) {
                val now = System.nanoTime()
                val cap = maxOf(rate, 256L * 1024).toDouble()
                available = minOf(cap, available + (now - last) / 1e9 * rate)
                last = now
                if (available >= n) {
                    available -= n
                    0L
                } else {
                    (((n - available) / rate) * 1000).toLong().coerceAtLeast(5)
                }
            }
            if (wait == 0L) return
            delay(wait)
        }
    }
}
