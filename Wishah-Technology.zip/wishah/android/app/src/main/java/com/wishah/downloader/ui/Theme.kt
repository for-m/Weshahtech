package com.wishah.downloader.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.TextFieldColors
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// هوية وشاح: حبر ليلي، ذهب شمباني، عاج حريري
val Ink = Color(0xFF0E1020)
val Ink2 = Color(0xFF141731)
val Ink3 = Color(0xFF1C2042)
val Gold = Color(0xFFC9A45C)
val GoldHi = Color(0xFFE9D29A)
val GoldLo = Color(0xFF8A6A2E)
val Ivory = Color(0xFFF3EBDD)
val Muted = Color(0xFF9A97A8)
val Rule = Color(0x29C9A45C)
val Jade = Color(0xFF3FA37A)
val Garnet = Color(0xFFC4566A)
val Sky = Color(0xFF7C9CE0)

@Composable
fun WishahTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold, onPrimary = Color(0xFF1A1408),
            secondary = GoldHi, onSecondary = Color(0xFF1A1408),
            background = Ink, onBackground = Ivory,
            surface = Ink2, onSurface = Ivory,
            surfaceVariant = Ink3, onSurfaceVariant = Muted,
            surfaceContainerHigh = Ink2, surfaceContainerHighest = Ink3,
            outline = Rule, error = Garnet,
        ),
        typography = Typography(),
        content = content,
    )
}

@Composable
fun goldFieldColors(): TextFieldColors = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Gold,
    unfocusedBorderColor = Rule,
    focusedLabelColor = Gold,
    cursorColor = Gold,
    focusedTextColor = Ivory,
    unfocusedTextColor = Ivory,
)
