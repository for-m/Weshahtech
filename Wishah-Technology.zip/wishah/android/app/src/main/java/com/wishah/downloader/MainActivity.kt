package com.wishah.downloader

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.mutableStateOf
import com.wishah.downloader.engine.Downloads
import com.wishah.downloader.ui.WishahRoot
import com.wishah.downloader.ui.WishahTheme

class MainActivity : ComponentActivity() {
    private val sharedUrl = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Downloads.init(this)
        handle(intent)
        setContent {
            WishahTheme {
                WishahRoot(sharedUrl = sharedUrl.value, onSharedConsumed = { sharedUrl.value = null })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        Regex("https?://\\S+", RegexOption.IGNORE_CASE).find(text)?.let { sharedUrl.value = it.value }
    }
}
